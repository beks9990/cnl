#include<stdio.h>
#include<stdlib.h>
#include<inttypes.h>
uint64_t factorial(uint64_t n);
int main(int argc,char *argv[])
{	int num=atoi(argv[1]);				//ascii to int atoi
	int num2;
    num2=factorial(num);
	printf("Factorial is %i\n",num2);
	return 0;
}
/*nasm -f elf64 factm.nasm && gcc -std=c99 factm.o factm.c && ./a.out  10*/

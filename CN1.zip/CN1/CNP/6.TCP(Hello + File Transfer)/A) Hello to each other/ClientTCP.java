import java.io.*;
import java.net.*;
import java.util.*;
public class ClientTCP 
{
	Socket sc;
	DataOutputStream out;
	DataInputStream in;
	Scanner ss;
	ClientTCP ()
	{
		try
		{	 
			sc=new Socket("localhost",8050);
			in=new DataInputStream(sc.getInputStream());
			out=new DataOutputStream(sc.getOutputStream());
			ss=new Scanner(System.in);
			while(true)
			{
				System.out.println("Enter Your Message : ");
				out.writeUTF(ss.nextLine());
				System.out.println("Server >>>"+in.readUTF());
			}
		}
		catch(Exception e)
		{
			System.out.println(""+e);
		}
	}
	public static void main(String ar[])
	{
	ClientTCP  cs=new ClientTCP();
	}
}
/*

saurabh@saurabh-HP-Laptop-15g-dr0xxx:~$ javac ClientTCP.java
saurabh@saurabh-HP-Laptop-15g-dr0xxx:~$ java ClientTCP
Enter Your Message : 
hi
Server >>>hello
Enter Your Message : 
happy diwali
Server >>>happy diwali
Enter Your Message : 
ok
Server >>>s2y bro
Enter Your Message : 
ok
Server >>>bye
Enter Your Message : 
bbbbbbbyyyyyyeeee
Server >>>bye bro
Enter Your Message : 
i
Server >>>
Enter Your Message : 
o 
Server >>>o
Enter Your Message : 

*/

import java.net.*;
import java.util.Scanner;
import java.io.*;
public class ServerTCP 
{
	ServerSocket sc;
	Socket server;
	DataInputStream in;
	DataOutputStream out;
	Scanner ss;
	ServerTCP()
	{
		try

		{
			sc=new ServerSocket(8050);	
			server=sc.accept();
			ss=new Scanner(System.in);
			in=new DataInputStream(server.getInputStream());
			out=new DataOutputStream(server.getOutputStream());
			while(true)
			{
				System.out.println(server.getInetAddress()+" >>>"+in.readUTF());
				System.out.println("Enter Your Message : ");
				out.writeUTF(ss.nextLine());
			}
		}
		catch(Exception e)
		{
			System.out.println("Cannot Start Server");
		}
		
	}	
	public static void main(String at[])
	{
		ServerTCP scc=new ServerTCP();
	}
}
/*

saurabh@saurabh-HP-Laptop-15g-dr0xxx:~$ javac ServerTCP.java
saurabh@saurabh-HP-Laptop-15g-dr0xxx:~$ java ServerTCP
/127.0.0.1 >>>hi
Enter Your Message : 
hello
happy diwali
/127.0.0.1 >>>happy diwali
Enter Your Message : 
s2y bro
/127.0.0.1 >>>ok
Enter Your Message : 
bye
/127.0.0.1 >>>ok
Enter Your Message : 
/127.0.0.1 >>>bbbbbbbyyyyyyeeee
Enter Your Message : 
bye bro 

/127.0.0.1 >>>i
Enter Your Message : 
o

/127.0.0.1 >>>o
Enter Your Message : 

*/
